# leetcode_company_wise_questions
This is a repository containing the list of company wise questions available on leetcode premium.

Every pdf file in this repository corresponds to a list of questions on leetcode for a specific company based on the _leetcode company tags_. The list of questions within each pdf is further sorted by their frequency, so the most popular question for a specific company is at the top.
